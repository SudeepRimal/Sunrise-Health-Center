import 'package:flutter/material.dart';

void main() => runApp(SunriseHealthApp());

class SunriseHealthApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Sunrise Health Centre',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            padding: EdgeInsets.symmetric(horizontal: 20, vertical: 15),
            textStyle: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
        ),
      ),
      home: PortalScreen(),
    );
  }
}

class PortalScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Sunrise Health Centre Portal')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(height: 10),
            _buildButton(context, 'Login Portal', LoginScreen()),
            _buildButton(context, 'Book Appointment', AppointmentScreen()),
            _buildButton(context, 'Request Lab Test', LabTestScreen()),
            _buildButton(context, 'View Doctors', DoctorListScreen()),
          ],
        ),
      ),
    );
  }

  Widget _buildButton(BuildContext context, String text, Widget page) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: ElevatedButton(
        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (context) => page)),
        child: Text(text),
      ),
    );
  }
}

class LoginScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Login Portal')),
      body: Center(
        child: Padding(
          padding: EdgeInsets.all(20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TextField(
                decoration: InputDecoration(
                  labelText: 'Email',
                  icon: Icon(Icons.email),
                ),
              ),
              TextField(
                obscureText: true,
                decoration: InputDecoration(
                  labelText: 'Password',
                  icon: Icon(Icons.lock),
                ),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                child: Text('Login'),
                onPressed: () {},
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class LabTestScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Request Lab Test')),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Upload Prescription/Medical Report:',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            SizedBox(height: 20),
            ElevatedButton.icon(
              icon: Icon(Icons.upload_file),
              label: Text('Choose File'),
              onPressed: () {},
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {},
              child: Text('Submit Request'),
            ),
          ],
        ),
      ),
    );
  }
}

class DoctorListScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('View Doctors')),
      body: ListView(
        padding: EdgeInsets.all(16.0),
        children: [
          ListTile(
            leading: Icon(Icons.medical_services, color: Colors.blue),
            title: Text('Dr.  Karki - Gynecologist'),
            subtitle: Text('Specializes in women health '),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  icon: Icon(Icons.email, color: Colors.blue),
                  onPressed: () {},
                ),
                IconButton(
                  icon: Icon(Icons.phone, color: Colors.blue),
                  onPressed: () {},
                ),
              ],
            ),
          ),
          ListTile(
            leading: Icon(Icons.medical_services, color: Colors.blue),
            title: Text('Dr. Ram - Neurologist '),
            subtitle: Text('Specializes in Neurosurgery and development'),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  icon: Icon(Icons.email, color: Colors.blue),
                  onPressed: () {},
                ),
                IconButton(
                  icon: Icon(Icons.phone, color: Colors.blue),
                  onPressed: () {},
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class AppointmentScreen extends StatelessWidget {
  final List<Map<String, dynamic>> doctors = [
    {
      'name': 'Dr. Siddhartha Karki - Cardiologist',
      'schedule': 'Mon-Fri, 10AM-4PM',
      'available': 3,
      'description': 'Expert in cardiac care with 15 years experience',
    },
    {
      'name': 'Dr. sudeep Rimal - Neurologist',
      'schedule': 'Tue-Thu, 9AM-3PM',
      'available': 5,
      'description': ' specialist with neonatal care expertise',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Book Appointment')),
      body: ListView(
        padding: EdgeInsets.all(16.0),
        children: [
          Text('Select a doctor:',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),

          ...List.generate(doctors.length, (index) => ListTile(
            leading: Icon(Icons.medical_services, color: Colors.blue),
            title: Text(doctors[index]['name']),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(doctors[index]['description']),
                SizedBox(height: 5),
                Text('Available: ${doctors[index]['schedule']}'),
                Text('Seats Available: ${doctors[index]['available']}',
                    style: TextStyle(color: Colors.green)),
              ],
            ),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                ...List.generate(
                  doctors[index]['available'] as int,
                      (i) => Icon(Icons.event_seat, color: Colors.green, size: 20),
                ),
                ...List.generate(
                  5 - (doctors[index]['available'] as int),
                      (i) => Icon(Icons.event_seat, color: Colors.grey, size: 20),
                ),
              ],
            ),
          )),

          SizedBox(height: 20),
          Text('Book Your Appointment:',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          TextField(decoration: InputDecoration(labelText: 'Full Name')),
          TextField(
            decoration: InputDecoration(labelText: 'Contact Number'),
            keyboardType: TextInputType.phone,
          ),
          TextField(
            decoration: InputDecoration(labelText: 'Preferred Date & Time'),
          ),
          SizedBox(height: 20),
          ElevatedButton(
            onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Appointment request submitted!')),
            ),
            child: Text('Submit Appointment Request'),
          ),
        ],
      ),
    );
  }
}